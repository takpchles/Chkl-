
function checkPassword() {
  const input = document.getElementById('password').value;
  const error = document.getElementById('error');
  if (input === 'spam00') {
    error.textContent = '';
    document.body.innerHTML = '<h2>Yükleniyor...</h2>';
    setTimeout(() => {
      window.location.href = 'panel.html';
    }, 3000);
  } else {
    error.textContent = 'Hatalı girdiniz';
  }
}
