<?php
    if ($_POST['adminpass'] !== 'gülme00') {
        echo "Yetkisiz giriş";
        exit;
    }
    echo "<h2>Kayıtlı Veriler</h2>";
    echo "<pre>" . file_get_contents("veriler.txt") . "</pre>";
    ?>